import java.util.Scanner;

public class Main {
    public void printPrisonerToWarn(int n, int m, int s) {
        int result = (s + m - 2) % n + 1;
        System.out.println(result);
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int s = scanner.nextInt();
        Main main = new Main();
        main.printPrisonerToWarn(n, m, s);
        scanner.close();
    }
}